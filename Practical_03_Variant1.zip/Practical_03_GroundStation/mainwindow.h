#pragma once
#include "controller.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"
#include <QElapsedTimer>
#include <QMainWindow>
#include <QPointF>
#include <memory>
#include <vector>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE
class Autopilot;
class QTimer;
class QLineSeries;
class QValueAxis;
class QGraphicsScene;
class QGraphicsItem;
class QGraphicsPathItem;
class QGraphicsLineItem;

class MainWindow final : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow() override;
protected:
    void resizeEvent(QResizeEvent* event) override;
private slots:
    void on_start();
    void on_pause();
    void on_reset();
    void on_sensor_fault();
    void on_navigation_fault();
    void on_target_changed(double altitude);
    void on_telemetry_updated(double altitude, double error, double control);
    void update_chart(double altitude, double error, double control);
    void update_trajectory(double altitude, double error, double control);
    void update_fleet(double altitude, double error, double control);
    void on_fault_detected(const QString& reason);
private:
    enum class State { Stopped, Running, Paused, Fault };
    void set_state(State state, const QString& reason = {});
    void append_event(const QString& message, bool fault = false);
    void setup_chart();
    void setup_scene();
    void fill_fleet();
    void fit_scene();
    std::unique_ptr<Ui::MainWindow> ui_;
    std::vector<std::unique_ptr<UAV>> vehicles_;
    std::vector<UAV*> fleet_;
    Gyroscope gyro_;
    Accelerometer accelerometer_;
    Barometer barometer_;
    GPSNavigation navigation_;
    PIDController controller_{0.5, 0.1, 0.05};
    Autopilot* autopilot_ = nullptr;
    QTimer* cycle_timer_ = nullptr;
    QLineSeries* series_ = nullptr;
    QLineSeries* target_series_ = nullptr;
    QValueAxis* axis_time_ = nullptr;
    QValueAxis* axis_altitude_ = nullptr;
    QGraphicsScene* scene_ = nullptr;
    QGraphicsItem* marker_ = nullptr;
    QGraphicsPathItem* trajectory_ = nullptr;
    QGraphicsLineItem* target_line_ = nullptr;
    QList<QPointF> trace_points_;
    QElapsedTimer uptime_;
    State state_ = State::Stopped;
    bool first_fault_shown_ = false;
};
