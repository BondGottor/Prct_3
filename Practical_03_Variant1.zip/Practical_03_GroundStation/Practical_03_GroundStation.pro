QT += core gui widgets charts
CONFIG += c++17 no_moc_predefs
TEMPLATE = app
TARGET = Practical_03_GroundStation
SOURCES += main.cpp mainwindow.cpp uav.cpp sensor.cpp navigation.cpp controller.cpp autopilot.cpp
HEADERS += mainwindow.h uav.h sensor.h navigation.h controller.h autopilot.h
FORMS += mainwindow.ui
QMAKE_UIC_FLAGS += -a
win32-g++: QMAKE_CXXFLAGS += -finput-charset=UTF-8 -fexec-charset=UTF-8
win32-msvc: QMAKE_CXXFLAGS += /utf-8
