#include "autopilot.h"
#include "controller.h"
#include "navigation.h"
#include "sensor.h"
#include "uav.h"
#include <cmath>
#include <exception>
#include <stdexcept>

Autopilot::Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
                     NavigationSystem* navigation, FlightController* controller,
                     QObject* parent)
    : QObject(parent), vehicle_(vehicle), sensors_(sensors),
      navigation_(navigation), controller_(controller) {}
double Autopilot::elapsed_seconds() const { return double(cycles_) * cycle_dt(); }
double Autopilot::target_altitude() const { return target_altitude_; }
void Autopilot::set_target_altitude(double altitude) {
    if (!std::isfinite(altitude) || altitude < 50 || altitude > 500)
        throw std::invalid_argument("Target altitude must be between 50 and 500 m");
    target_altitude_ = altitude;
}
void Autopilot::fail(const QString& reason) { emit fault_detected(reason); }
void Autopilot::run_cycle() {
    if (!vehicle_) { fail("Аппарат не задан (vehicle is not set)"); return; }
    if (sensors_.empty()) { fail("Список сенсоров пуст"); return; }
    for (Sensor* sensor : sensors_) {
        if (!sensor || !sensor->is_ready()) {
            fail(QString("Отказ сенсора: %1").arg(sensor ? sensor->name() : "unknown"));
            return;
        }
        if (!std::isfinite(sensor->read())) {
            fail("Некорректное показание: " + sensor->name()); return;
        }
    }
    if (!navigation_ || !navigation_->is_valid()) {
        fail("Навигация GPS невалидна (navigation data invalid)"); return;
    }
    if (!controller_) { fail("Контроллер не задан"); return; }
    try {
        const double altitude = navigation_->get_position().altitude();
        if (!std::isfinite(altitude) || altitude < 0) {
            fail("Некорректная высота навигации"); return;
        }
        const double error = target_altitude_ - altitude;
        const double control = controller_->calculate_control(error, cycle_dt());
        if (!std::isfinite(control)) { fail("Некорректный сигнал управления"); return; }
        navigation_->simulate_step(control, cycle_dt());
        ++cycles_;
        // Пакет описывает измерение и управление одного и того же цикла.
        emit telemetry_updated(altitude, error, control);
    } catch (const std::exception& exception) {
        fail("Ошибка модели: " + QString::fromUtf8(exception.what()));
    }
}
