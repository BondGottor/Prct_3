#pragma once
#include <QString>
class Position {
public:
    explicit Position(double altitude = 150.0);
    double altitude() const;
private:
    double altitude_;
};
class NavigationSystem {
public:
    virtual ~NavigationSystem() = default;
    virtual bool is_valid() const = 0;
    virtual Position get_position() const = 0;
    virtual QString name() const = 0;
    virtual void simulate_step(double control, double dt) = 0;
};
class GPSNavigation final : public NavigationSystem {
public:
    bool is_valid() const override;
    Position get_position() const override;
    QString name() const override;
    void set_valid(bool valid);
    void simulate_step(double control, double dt) override;
private:
    bool valid_ = true;
    double altitude_ = 150.0;
};
