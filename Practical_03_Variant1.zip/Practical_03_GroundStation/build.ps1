param(
    [string]$QtRoot = 'C:\Qt\6.12.0\mingw_64',
    [string]$CompilerRoot = 'C:\Qt\Tools\mingw1310_64',
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
$env:PATH = "$CompilerRoot\bin;$QtRoot\bin;" + $env:PATH
$qmake = Join-Path $QtRoot 'bin\qmake.exe'
$make = Join-Path $CompilerRoot 'bin\mingw32-make.exe'
foreach ($tool in @($qmake, $make)) {
    if (!(Test-Path -LiteralPath $tool)) { throw "Tool not found: $tool" }
}
function Build-Project([string]$Directory, [string]$Project) {
    New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot $Directory) | Out-Null
    Push-Location -LiteralPath (Join-Path $PSScriptRoot $Directory)
    try {
        & $qmake "..\$Project" -o Makefile 'CONFIG+=release'
        if ($LASTEXITCODE -ne 0) { throw 'qmake failed' }
        & $make -f Makefile.Release -j 4
        if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
    } finally { Pop-Location }
}
Build-Project 'build-qmake' 'Practical_03_GroundStation.pro'
if (!$SkipTests) {
    Build-Project 'build-tests' 'station_tests.pro'
    New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'screenshots') | Out-Null
    $env:QT_QPA_PLATFORM = 'offscreen'
    $env:STATION_CAPTURE_DIR = Join-Path $PSScriptRoot 'screenshots'
    Push-Location -LiteralPath (Join-Path $PSScriptRoot 'build-tests')
    try {
        & '.\release\station_tests.exe' -o '..\test-results.txt,txt' -o '-,txt'
        if ($LASTEXITCODE -ne 0) { throw 'Tests failed; see test-results.txt' }
    } finally { Pop-Location }
    Remove-Item Env:QT_QPA_PLATFORM
    Remove-Item Env:STATION_CAPTURE_DIR
}
$windowsDir = Join-Path $PSScriptRoot 'Windows'
New-Item -ItemType Directory -Force -Path $windowsDir | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'build-qmake\release\Practical_03_GroundStation.exe') -Destination $windowsDir -Force
Push-Location -LiteralPath $windowsDir
try {
    & (Join-Path $QtRoot 'bin\windeployqt.exe') --release --no-translations --no-system-d3d-compiler --no-opengl-sw 'Practical_03_GroundStation.exe'
    if ($LASTEXITCODE -ne 0) { throw 'windeployqt failed' }
} finally { Pop-Location }
@'
[Paths]
Prefix=.
Plugins=.
'@ | Set-Content -LiteralPath (Join-Path $windowsDir 'qt.conf') -Encoding ascii

# Проверка поставки с системным PATH: Qt и компилятор не доступны извне.
$savedPath = $env:PATH
$savedPluginPath = $env:QT_PLUGIN_PATH
$smokeProcess = $null
try {
    $env:PATH = "$env:SystemRoot\System32;$env:SystemRoot"
    $env:QT_PLUGIN_PATH = $windowsDir
    $smokeProcess = Start-Process -FilePath (Join-Path $windowsDir 'Practical_03_GroundStation.exe') -WorkingDirectory $windowsDir -WindowStyle Hidden -PassThru
    if (!$smokeProcess.WaitForInputIdle(5000)) { throw 'Standalone startup timeout' }
    Start-Sleep -Milliseconds 600
    $smokeProcess.Refresh()
    if ($smokeProcess.HasExited) { throw "Standalone application exited: $($smokeProcess.ExitCode)" }
    'PASS: Windows x64 application started with the Windows QPA plugin, local DLLs, and a system-only PATH.' |
        Set-Content -LiteralPath (Join-Path $PSScriptRoot 'standalone-smoke.txt') -Encoding utf8
} finally {
    $env:PATH = $savedPath
    $env:QT_PLUGIN_PATH = $savedPluginPath
    if ($null -ne $smokeProcess -and !$smokeProcess.HasExited) {
        $null = $smokeProcess.CloseMainWindow()
        if (!$smokeProcess.WaitForExit(2500)) { Stop-Process -Id $smokeProcess.Id }
    }
}
Write-Host 'Ready: Windows\Practical_03_GroundStation.exe'
