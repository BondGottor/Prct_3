#include "sensor.h"
ReadySensor::ReadySensor(double value) : value_(value) {}
double ReadySensor::read() const { return value_; }
bool ReadySensor::is_ready() const { return ready_; }
void ReadySensor::set_ready(bool ready) { ready_ = ready; }
Gyroscope::Gyroscope(double value) : ReadySensor(value) {}
QString Gyroscope::name() const { return "Gyroscope"; }
Accelerometer::Accelerometer(double value) : ReadySensor(value) {}
QString Accelerometer::name() const { return "Accelerometer"; }
Barometer::Barometer(double value) : ReadySensor(value) {}
QString Barometer::name() const { return "Barometer"; }
