include(Practical_03_GroundStation.pro)
QT += testlib
CONFIG += console testcase
CONFIG -= app_bundle
TARGET = station_tests
SOURCES -= main.cpp
SOURCES += tests.cpp
