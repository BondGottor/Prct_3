#include "navigation.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>
Position::Position(double altitude) : altitude_(altitude) {}
double Position::altitude() const { return altitude_; }
bool GPSNavigation::is_valid() const { return valid_; }
Position GPSNavigation::get_position() const { return Position(altitude_); }
QString GPSNavigation::name() const { return "GPS"; }
void GPSNavigation::set_valid(bool valid) { valid_ = valid; }
void GPSNavigation::simulate_step(double control, double dt) {
    if (!std::isfinite(control) || !std::isfinite(dt) || dt <= 0)
        throw std::invalid_argument("Invalid simulation step");
    // Учебная кинематика: сигнал управления задаёт вертикальную скорость.
    // Ограничение скорости +/-12 м/с; это демонстрация, не динамика БПЛА.
    altitude_ = std::max(0.0, altitude_ + std::clamp(control, -12.0, 12.0) * dt);
}
