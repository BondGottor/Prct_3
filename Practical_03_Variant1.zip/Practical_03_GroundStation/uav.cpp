#include "uav.h"
bool UAV::is_flying() const { return flying_; }
void UAV::set_flying(bool value) { flying_ = value; }
QString Quadcopter::type() const { return "Quadcopter"; }
int Quadcopter::motor_count() const { return 4; }
void Quadcopter::takeoff() { set_flying(true); }
void Quadcopter::land() { set_flying(false); }
QString FixedWingUAV::type() const { return "FixedWingUAV"; }
int FixedWingUAV::motor_count() const { return 1; }
void FixedWingUAV::takeoff() { set_flying(true); }
void FixedWingUAV::land() { set_flying(false); }
