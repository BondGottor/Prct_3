#include "controller.h"
#include <cmath>
#include <stdexcept>
PIDController::PIDController(double kp, double ki, double kd) : kp_(kp), ki_(ki), kd_(kd) {
    if (!std::isfinite(kp) || !std::isfinite(ki) || !std::isfinite(kd))
        throw std::invalid_argument("Invalid PID coefficients");
}
double PIDController::calculate_control(double error, double dt) {
    if (!std::isfinite(error) || !std::isfinite(dt) || dt <= 0)
        throw std::invalid_argument("Invalid PID input");
    const double integral = integral_ + error * dt;
    const double derivative = (error - previous_error_) / dt;
    const double control = kp_ * error + ki_ * integral + kd_ * derivative;
    if (!std::isfinite(control)) throw std::overflow_error("PID overflow");
    integral_ = integral;
    previous_error_ = error;
    return control;
}
