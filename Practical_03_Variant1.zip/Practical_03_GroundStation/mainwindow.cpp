#include "mainwindow.h"
#include "autopilot.h"
#include "ui_mainwindow.h"
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <QGraphicsItem>
#include <QGraphicsScene>
#include <QHeaderView>
#include <QMessageBox>
#include <QPainter>
#include <QPainterPath>
#include <QPushButton>
#include <QResizeEvent>
#include <QStyle>
#include <QTimer>
#include <algorithm>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent), ui_(std::make_unique<Ui::MainWindow>()) {
    ui_->setupUi(this);
    uptime_.start();
    setStyleSheet(R"(
        QMainWindow, QWidget#centralwidget { background: #0d1524; color: #e4ecf8; }
        QWidget { font-family: 'Segoe UI'; font-size: 13px; color: #e4ecf8; }
        QLabel { background: transparent; }
        QLabel#labelEyebrow { color: #65ddc2; font-size: 11px; font-weight: 600; }
        QLabel#labelTitle { font-size: 27px; font-weight: 600; }
        QLabel#labelRate { color: #8da3bf; font-size: 12px; }
        QFrame[card="true"] { background: #151f31; border: 1px solid #26364d; border-radius: 10px; }
        QLabel[caption="true"] { color: #91a6c2; font-size: 11px; font-weight: 600; }
        QLabel[metric="true"] { font-size: 32px; font-weight: 600; color: #f2f7ff; }
        QLabel#labelOutput { color: #65ddc2; }
        QLabel[section="true"] { font-size: 14px; font-weight: 600; padding: 3px 2px 7px; }
        QLabel[hint="true"], QLabel#labelFooter { color: #859bb8; font-size: 11px; }
        QLabel#labelTime { color: #9eb4d1; padding-right: 12px; }
        QLabel#labelStatus { border-radius: 7px; padding: 0 14px; font-weight: 600; }
        QLabel#labelStatus[state="stopped"] { background: #1a273d; color: #b9cbe3; }
        QLabel#labelStatus[state="running"] { background: #123a35; color: #76efd3; }
        QLabel#labelStatus[state="paused"] { background: #41341b; color: #ffce77; }
        QLabel#labelStatus[state="fault"] { background: #4a202c; color: #ff9faf; }
        QPushButton { background: #22324c; border: 1px solid #364b68; border-radius: 6px;
                      padding: 10px 18px; font-weight: 600; }
        QPushButton:hover { background: #2c4160; }
        QPushButton:pressed { background: #16263e; }
        QPushButton:disabled { color: #667c99; background: #172238; border-color: #25334a; }
        QPushButton#btnStart { background: #55d5b6; border-color: #55d5b6; color: #09241e; }
        QPushButton#btnStart:hover { background: #83e7ce; }
        QPushButton#btnFaultSensor, QPushButton#btnFaultNavigation { color: #ffb3bd; border-color: #75404c; background: #302032; }
        QDoubleSpinBox { background: #101a2a; border: 1px solid #3c526e; border-radius: 5px;
                         font-size: 25px; font-weight: 600; padding: 2px 8px; min-height: 35px; }
        QTableWidget, QListWidget, QGraphicsView { background: #111b2c; border: none; border-radius: 4px; }
        QTableWidget::item { padding: 6px; border-bottom: 1px solid #24344a; }
        QTableWidget::item:selected, QListWidget::item:selected { background: #263d58; }
        QHeaderView::section { background: #1c2b41; color: #a6bad4; border: none; padding: 8px 6px; font-size: 12px; }
        QTableCornerButton::section { background: #1c2b41; border: none; }
        QListWidget::item { padding: 7px 8px; border-bottom: 1px solid #202f45; }
        QScrollBar:vertical { background: #142037; width: 9px; }
        QScrollBar::handle:vertical { background: #405775; min-height: 20px; border-radius: 4px; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        QMessageBox { background: #151f31; }
    )");
    for (auto* card : {ui_->cardAltitude, ui_->cardError, ui_->cardOutput, ui_->cardTarget,
                       ui_->cardChart, ui_->cardScene, ui_->cardFleet, ui_->cardLog})
        card->setProperty("card", true);
    for (auto* label : {ui_->captionAltitude, ui_->captionError, ui_->captionOutput, ui_->captionTarget})
        label->setProperty("caption", true);
    for (auto* label : {ui_->labelAltitude, ui_->labelError, ui_->labelOutput}) label->setProperty("metric", true);
    for (auto* label : {ui_->titleChart, ui_->titleScene, ui_->titleFleet, ui_->titleLog}) label->setProperty("section", true);
    for (auto* label : {ui_->labelSceneHint, ui_->labelFleetHint}) label->setProperty("hint", true);

    // Вариант 1 предыдущей работы: Quadcopter и FixedWingUAV.
    // Три экземпляра, два типа: квадрокоптер, самолёт, резервный квадрокоптер.
    vehicles_.push_back(std::make_unique<Quadcopter>());
    vehicles_.push_back(std::make_unique<FixedWingUAV>());
    vehicles_.push_back(std::make_unique<Quadcopter>());
    for (const auto& vehicle : vehicles_) fleet_.push_back(vehicle.get());
    fill_fleet();
    autopilot_ = new Autopilot(fleet_.front(), {&gyro_, &accelerometer_, &barometer_},
                               &navigation_, &controller_, this);
    autopilot_->setObjectName("autopilot");
    cycle_timer_ = new QTimer(this);
    cycle_timer_->setObjectName("cycleTimer");
    cycle_timer_->setInterval(100);
    cycle_timer_->setTimerType(Qt::PreciseTimer);
    setup_chart();
    setup_scene();

    connect(cycle_timer_, &QTimer::timeout, autopilot_, &Autopilot::run_cycle);
    // Один сигнал телеметрии, четыре независимых получателя.
    connect(autopilot_, &Autopilot::telemetry_updated, this, &MainWindow::on_telemetry_updated);
    connect(autopilot_, &Autopilot::telemetry_updated, this, &MainWindow::update_chart);
    connect(autopilot_, &Autopilot::telemetry_updated, this, &MainWindow::update_trajectory);
    connect(autopilot_, &Autopilot::telemetry_updated, this, &MainWindow::update_fleet);
    connect(autopilot_, &Autopilot::fault_detected, this, &MainWindow::on_fault_detected);
    connect(ui_->btnStart, &QPushButton::clicked, this, &MainWindow::on_start);
    connect(ui_->btnPause, &QPushButton::clicked, this, &MainWindow::on_pause);
    connect(ui_->btnReset, &QPushButton::clicked, this, &MainWindow::on_reset);
    connect(ui_->btnFaultSensor, &QPushButton::clicked, this, &MainWindow::on_sensor_fault);
    connect(ui_->btnFaultNavigation, &QPushButton::clicked, this, &MainWindow::on_navigation_fault);
    connect(ui_->spinTarget, &QDoubleSpinBox::valueChanged, this, &MainWindow::on_target_changed);
    set_state(State::Stopped);
    append_event("Станция готова. Подключено 3 аппарата; активен UAV-01.");
    setStyleSheet(styleSheet()); // Пересчитать стиль после установки свойств карточек.
}
MainWindow::~MainWindow() {
    cycle_timer_->stop();
    // QObject-ребёнок удаляется до его не владеющих зависимостей-членов.
    delete autopilot_;
}
void MainWindow::fill_fleet() {
    ui_->tableFleet->setRowCount(int(fleet_.size()));
    const int batteries[] = {86, 92, 78};
    for (int row = 0; row < int(fleet_.size()); ++row) {
        UAV* vehicle = fleet_[size_t(row)];
        const int motors = vehicle->motor_count();
        const QStringList values{QString("UAV-%1").arg(row + 1, 2, 10, QChar('0')),
            vehicle->type(), QString::number(batteries[row]) + " %",
            motors < 0 ? "—" : QString::number(motors), "Connected"};
        for (int column = 0; column < values.size(); ++column)
            ui_->tableFleet->setItem(row, column, new QTableWidgetItem(values[column]));
        ui_->tableFleet->item(row, 2)->setForeground(QColor("#65ddc2"));
        ui_->tableFleet->item(row, 3)->setTextAlignment(Qt::AlignCenter);
    }
    ui_->tableFleet->verticalHeader()->hide();
    ui_->tableFleet->verticalHeader()->setDefaultSectionSize(38);
    ui_->tableFleet->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui_->tableFleet->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    ui_->tableFleet->setMinimumHeight(159);
}
void MainWindow::setup_chart() {
    auto* chart = new QChart;
    chart->setTheme(QChart::ChartThemeDark);
    chart->setBackgroundBrush(QColor("#151f31"));
    chart->setPlotAreaBackgroundBrush(QColor("#111b2c"));
    chart->setPlotAreaBackgroundVisible(true);
    chart->setBackgroundRoundness(0);
    chart->setMargins(QMargins(2, 0, 2, 0));
    chart->setAnimationOptions(QChart::NoAnimation);
    series_ = new QLineSeries(chart);
    series_->setObjectName("altitudeSeries");
    series_->setName("Высота");
    series_->setPen(QPen(QColor("#65ddc2"), 2.5));
    target_series_ = new QLineSeries(chart);
    target_series_->setName("Цель");
    target_series_->setPen(QPen(QColor("#a7b5cc"), 1.2, Qt::DashLine));
    chart->addSeries(series_);
    chart->addSeries(target_series_);
    axis_time_ = new QValueAxis(chart);
    axis_time_->setTitleText("Время моделирования, с");
    axis_time_->setRange(0, 20);
    axis_time_->setTickCount(5);
    axis_time_->setLabelFormat("%.0f");
    axis_altitude_ = new QValueAxis(chart);
    axis_altitude_->setTitleText("Высота, м");
    axis_altitude_->setRange(100, 240);
    axis_altitude_->setTickCount(5);
    axis_altitude_->setLabelFormat("%.0f");
    for (auto* axis : {axis_time_, axis_altitude_}) {
        axis->setGridLineColor(QColor("#2a3b52"));
        axis->setLabelsColor(QColor("#9eb4d1"));
        axis->setTitleBrush(QColor("#9eb4d1"));
        axis->setLabelsFont(QFont("Segoe UI", 9));
        axis->setTitleFont(QFont("Segoe UI", 9));
    }
    chart->addAxis(axis_time_, Qt::AlignBottom);
    chart->addAxis(axis_altitude_, Qt::AlignLeft);
    for (auto* series : {series_, target_series_}) {
        series->attachAxis(axis_time_);
        series->attachAxis(axis_altitude_);
    }
    target_series_->append(0, 200);
    target_series_->append(20, 200);
    chart->legend()->setAlignment(Qt::AlignTop);
    chart->legend()->setFont(QFont("Segoe UI", 9));
    chart->legend()->setLabelColor(QColor("#b2c5df"));
    ui_->chartView->setChart(chart);
    ui_->chartView->setRenderHint(QPainter::Antialiasing);
}
void MainWindow::setup_scene() {
    scene_ = new QGraphicsScene(this);
    scene_->setObjectName("flightScene");
    scene_->setSceneRect(0, -260, 480, 280);
    scene_->setBackgroundBrush(QColor("#111b2c"));
    for (int y = 0; y <= 550; y += 50) {
        scene_->addLine(0, -y, 480, -y, QPen(QColor("#263850"), 0));
        auto* text = scene_->addSimpleText(QString::number(y) + " м", QFont("Segoe UI", 8));
        text->setBrush(QColor("#788fab"));
        text->setPos(5, -y + 2);
    }
    for (int x = 0; x <= 480; x += 60)
        scene_->addLine(x, -550, x, 20, QPen(QColor("#203147"), 0));
    target_line_ = scene_->addLine(0, -200, 480, -200, QPen(QColor("#9caec8"), 1, Qt::DashLine));
    trajectory_ = scene_->addPath(QPainterPath(), QPen(QColor("#65ddc2"), 2));
    trajectory_->setZValue(1);
    auto* body = scene_->addEllipse(-4, -4, 8, 8, QPen(QColor("#e2fff7")), QBrush(QColor("#65ddc2")));
    QList<QGraphicsItem*> parts{body};
    parts << scene_->addLine(-9, -9, 9, 9, QPen(QColor("#b2ffeb"), 2));
    parts << scene_->addLine(-9, 9, 9, -9, QPen(QColor("#b2ffeb"), 2));
    for (int x : {-10, 10}) for (int y : {-10, 10})
        parts << scene_->addEllipse(x - 4, y - 4, 8, 8, QPen(QColor("#65ddc2"), 1.5), QBrush(QColor("#173d3b")));
    marker_ = scene_->createItemGroup(parts);
    marker_->setZValue(3);
    marker_->setData(0, "uavMarker");
    marker_->setPos(0, -150);
    ui_->graphicsView->setScene(scene_);
    ui_->graphicsView->setRenderHint(QPainter::Antialiasing);
    ui_->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui_->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui_->graphicsView->setInteractive(false);
}
void MainWindow::set_state(State state, const QString& reason) {
    state_ = state;
    QString key;
    QString text;
    switch (state) {
    case State::Stopped: key = "stopped"; text = "Stopped · Ожидание старта"; break;
    case State::Running: key = "running"; text = "Running · Mission status: Active · Сенсоры и GPS готовы"; break;
    case State::Paused: key = "paused"; text = "Paused · Пауза. Состояние полёта сохранено"; break;
    case State::Fault: key = "fault"; text = "FAULT · " + reason; break;
    }
    ui_->labelStatus->setText(text);
    ui_->labelStatus->setProperty("state", key);
    ui_->labelStatus->style()->unpolish(ui_->labelStatus);
    ui_->labelStatus->style()->polish(ui_->labelStatus);
    ui_->labelStatus->update();
    ui_->btnPause->setEnabled(state == State::Running);
    ui_->btnStart->setEnabled(state != State::Running);
    const QString fleet_state = state == State::Fault ? "FAULT" : state == State::Paused ? "Paused" :
                                state == State::Running ? "Running" : "Connected";
    ui_->tableFleet->item(0, 4)->setText(fleet_state);
    ui_->tableFleet->item(0, 4)->setForeground(state == State::Fault ? QColor("#ff9faf") : QColor("#65ddc2"));
}
void MainWindow::append_event(const QString& message, bool fault) {
    const qint64 ms = uptime_.elapsed();
    const QString stamp = QString("%1:%2.%3").arg(ms / 60000, 2, 10, QChar('0'))
        .arg((ms / 1000) % 60, 2, 10, QChar('0')).arg(ms % 1000, 3, 10, QChar('0'));
    auto* item = new QListWidgetItem("[" + stamp + "] " + message, ui_->listEvents);
    item->setForeground(fault ? QColor("#ff9faf") : QColor("#b6cae3"));
    // Журнал и графики имеют ограниченную историю для длительной работы.
    if (ui_->listEvents->count() > 500) delete ui_->listEvents->takeItem(0);
    ui_->listEvents->scrollToBottom();
}
void MainWindow::on_start() {
    if (cycle_timer_->isActive()) return;
    cycle_timer_->start();
    set_state(State::Running);
    append_event("Старт: цикл 100 мс. Продолжение сохранённой траектории.");
}
void MainWindow::on_pause() {
    if (state_ != State::Running) return;
    cycle_timer_->stop();
    set_state(State::Paused);
    append_event("Пауза: таймер остановлен; модель и ПИД сохранены.");
}
void MainWindow::on_reset() {
    cycle_timer_->stop();
    gyro_.set_ready(true);
    accelerometer_.set_ready(true);
    barometer_.set_ready(true);
    navigation_.set_valid(true);
    first_fault_shown_ = false;
    set_state(State::Running);
    cycle_timer_->start();
    append_event("Сброс: сенсоры и GPS восстановлены. Mission status: Active.");
}
void MainWindow::on_sensor_fault() {
    gyro_.set_ready(false);
    append_event("Команда: Gyroscope → Not ready. Проверка на следующем цикле.");
}
void MainWindow::on_navigation_fault() {
    navigation_.set_valid(false);
    append_event("Команда: GPS → invalid. Проверка на следующем цикле.");
}
void MainWindow::on_target_changed(double altitude) {
    autopilot_->set_target_altitude(altitude);
    append_event(QString("Целевая высота: %1 м.").arg(altitude, 0, 'f', 0));
    target_series_->replace({QPointF(axis_time_->min(), altitude), QPointF(axis_time_->max(), altitude)});
    target_line_->setLine(0, -altitude, 480, -altitude);
}
void MainWindow::on_telemetry_updated(double altitude, double error, double control) {
    ui_->labelAltitude->setText(QString::number(altitude, 'f', 1) + " м");
    ui_->labelError->setText(QString::number(error, 'f', 1) + " м");
    ui_->labelOutput->setText(QString::number(control, 'f', 2));
    ui_->labelTime->setText(QString("Полёт  %1 с").arg(autopilot_->elapsed_seconds(), 0, 'f', 1));
}
void MainWindow::update_chart(double altitude, double, double) {
    const double t = autopilot_->elapsed_seconds();
    series_->append(t, altitude);
    if (series_->count() > 600) series_->removePoints(0, series_->count() - 600);
    const double right = std::max(20.0, t);
    const double left = std::max(0.0, right - 60.0);
    axis_time_->setRange(left, right);
    double low = std::min(150.0, autopilot_->target_altitude());
    double high = std::max(200.0, autopilot_->target_altitude());
    for (const auto& p : series_->points()) { low = std::min(low, p.y()); high = std::max(high, p.y()); }
    axis_altitude_->setRange(std::max(0.0, low - 20), high + 25);
    target_series_->replace({QPointF(left, autopilot_->target_altitude()), QPointF(right, autopilot_->target_altitude())});
}
void MainWindow::update_trajectory(double altitude, double, double) {
    // Отображение координат; расчёт полётной динамики остаётся в модели.
    const double t = autopilot_->elapsed_seconds();
    trace_points_.append(QPointF(t * 8, -altitude));
    if (trace_points_.size() > 600) trace_points_.removeFirst();
    const double offset = std::max(0.0, t * 8 - 440);
    QPainterPath path;
    for (int i = 0; i < trace_points_.size(); ++i) {
        const QPointF p(trace_points_[i].x() - offset, trace_points_[i].y());
        if (i == 0) path.moveTo(p); else path.lineTo(p);
    }
    trajectory_->setPath(path); // Тот же item, меняется только его путь.
    marker_->setPos(t * 8 - offset, -altitude);
    const double top = std::max({260.0, altitude + 30, autopilot_->target_altitude() + 30});
    scene_->setSceneRect(-20, -top, 520, top + 20);
    fit_scene();
}
void MainWindow::update_fleet(double, double, double) {
    ui_->tableFleet->item(0, 4)->setText("Running");
}
void MainWindow::on_fault_detected(const QString& reason) {
    cycle_timer_->stop();
    set_state(State::Fault, reason);
    append_event("FAULT: " + reason, true);
    if (!first_fault_shown_) {
        first_fault_shown_ = true; // До модального диалога: защита от повторного входа.
        QMessageBox::warning(this, "Первая авария · Failsafe", reason +
            "\n\nЦикл остановлен. Нажмите «Сброс» для восстановления.\nПовторные аварии до сброса выводятся в статус и журнал.");
    }
}
void MainWindow::fit_scene() {
    if (scene_) ui_->graphicsView->fitInView(scene_->sceneRect(), Qt::KeepAspectRatio);
}
void MainWindow::resizeEvent(QResizeEvent* event) {
    QMainWindow::resizeEvent(event);
    fit_scene();
}
