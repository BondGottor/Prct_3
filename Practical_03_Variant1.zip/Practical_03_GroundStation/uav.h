#pragma once
#include <QString>

class UAV {
public:
    virtual ~UAV() = default;
    virtual QString type() const = 0;
    // Общий виртуальный интерфейс: -1 означает, что моторов нет.
    virtual int motor_count() const = 0;
    virtual void takeoff() = 0;
    virtual void land() = 0;
    bool is_flying() const;
protected:
    void set_flying(bool value);
private:
    bool flying_ = false;
};
class Quadcopter final : public UAV {
public:
    QString type() const override;
    int motor_count() const override;
    void takeoff() override;
    void land() override;
};
class FixedWingUAV final : public UAV {
public:
    QString type() const override;
    int motor_count() const override;
    void takeoff() override;
    void land() override;
};
