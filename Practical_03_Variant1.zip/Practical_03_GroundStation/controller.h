#pragma once
class FlightController {
public:
    virtual ~FlightController() = default;
    virtual double calculate_control(double error, double dt) = 0;
};
class PIDController final : public FlightController {
public:
    PIDController(double kp, double ki, double kd);
    double calculate_control(double error, double dt) override;
private:
    double kp_;
    double ki_;
    double kd_;
    double integral_ = 0;
    double previous_error_ = 0;
};
