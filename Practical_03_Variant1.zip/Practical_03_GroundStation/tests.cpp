#include "mainwindow.h"
#include "autopilot.h"
#include <QtCharts/QChartView>
#include <QtCharts/QChart>
#include <QtCharts/QLineSeries>
#include <QApplication>
#include <QDir>
#include <QDoubleSpinBox>
#include <QFontDatabase>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QLabel>
#include <QListWidget>
#include <QMessageBox>
#include <QPushButton>
#include <QSignalSpy>
#include <QTableWidget>
#include <QTimer>
#include <QtTest>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace {
struct Fixture {
    Quadcopter vehicle;
    Gyroscope gyro;
    Accelerometer accelerometer;
    Barometer barometer;
    GPSNavigation navigation;
    PIDController controller{0.5, 0.1, 0.05};
    Autopilot model{&vehicle, {&gyro, &accelerometer, &barometer}, &navigation, &controller};
};
QPushButton* button(MainWindow& w, const char* name) { return w.findChild<QPushButton*>(name); }
QLabel* label(MainWindow& w, const char* name) { return w.findChild<QLabel*>(name); }
QTimer* timer(MainWindow& w) { return w.findChild<QTimer*>("cycleTimer"); }
Autopilot* model(MainWindow& w) { return w.findChild<Autopilot*>("autopilot"); }
QLineSeries* series(MainWindow& w) {
    return qobject_cast<QLineSeries*>(w.findChild<QChartView*>("chartView")->chart()->series().front());
}
QGraphicsItem* marker(MainWindow& w) {
    for (auto* item : w.findChild<QGraphicsScene*>("flightScene")->items())
        if (item->data(0).toString() == "uavMarker") return item;
    return nullptr;
}
}

class StationTests final : public QObject {
    Q_OBJECT
private slots:
    void initTestCase();
    void pid_formula_and_validation();
    void model_cycle_and_signal();
    void model_faults_data();
    void model_faults();
    void target_changes_without_restart();
    void fleet_uses_polymorphism();
    void timer_pause_and_resume();
    void ui_fault_three_levels_and_reset();
    void long_run_bounds_and_marker_identity();
    void screenshot_scenarios();
};

void StationTests::initTestCase() {
    // Offscreen QPA не подхватывает системные шрифты Windows автоматически.
    const QDir fonts(qEnvironmentVariable("WINDIR", "C:/Windows") + "/Fonts");
    for (const auto& name : {"segoeui.ttf", "seguisb.ttf", "segoeuib.ttf"})
        QVERIFY(QFontDatabase::addApplicationFont(fonts.filePath(name)) >= 0);
    QApplication::setFont(QFont("Segoe UI", 10));
}

void StationTests::pid_formula_and_validation() {
    PIDController pid(0.5, 0.1, 0.05);
    QVERIFY(std::abs(pid.calculate_control(50, 0.1) - 50.5) < 1e-9);
    QVERIFY(std::abs(pid.calculate_control(50, 0.1) - 26.0) < 1e-9);
    QVERIFY_THROWS_EXCEPTION(std::invalid_argument, pid.calculate_control(1, 0));
    QVERIFY_THROWS_EXCEPTION(std::invalid_argument, pid.calculate_control(1, -0.1));
    QVERIFY_THROWS_EXCEPTION(std::invalid_argument, pid.calculate_control(std::numeric_limits<double>::quiet_NaN(), 0.1));
}
void StationTests::model_cycle_and_signal() {
    Fixture f;
    QSignalSpy telemetry(&f.model, &Autopilot::telemetry_updated);
    QSignalSpy faults(&f.model, &Autopilot::fault_detected);
    f.model.run_cycle();
    QCOMPARE(telemetry.count(), 1);
    QCOMPARE(faults.count(), 0);
    QCOMPARE(telemetry[0][0].toDouble(), 150.0);
    QCOMPARE(telemetry[0][1].toDouble(), 50.0);
    QVERIFY(std::abs(telemetry[0][2].toDouble() - 50.5) < 1e-9);
    QVERIFY(std::abs(f.model.elapsed_seconds() - 0.1) < 1e-9);
    QVERIFY(std::abs(f.navigation.get_position().altitude() - 151.2) < 1e-9);
    for (int i = 0; i < 1500; ++i) f.model.run_cycle();
    QCOMPARE(faults.count(), 0);
    QVERIFY(std::abs(telemetry.last()[1].toDouble()) < 0.01);
}
void StationTests::model_faults_data() {
    QTest::addColumn<int>("scenario");
    QTest::addColumn<QString>("reason");
    QTest::newRow("gyro-not-ready") << 0 << QString("Gyroscope");
    QTest::newRow("gps-invalid") << 1 << QString("navigation data invalid");
    QTest::newRow("null-vehicle") << 2 << QString("vehicle is not set");
    QTest::newRow("null-sensor") << 3 << QString("unknown");
    QTest::newRow("null-navigation") << 4 << QString("navigation data invalid");
    QTest::newRow("null-controller") << 5 << QString("Контроллер");
    QTest::newRow("empty-sensors") << 6 << QString("Список сенсоров пуст");
    QTest::newRow("nan-sensor") << 7 << QString("Некорректное показание");
}
void StationTests::model_faults() {
    QFETCH(int, scenario);
    QFETCH(QString, reason);
    Fixture f;
    Gyroscope invalid_sensor(std::numeric_limits<double>::quiet_NaN());
    std::vector<Sensor*> sensors{&f.gyro};
    if (scenario == 0) f.gyro.set_ready(false);
    if (scenario == 1) f.navigation.set_valid(false);
    if (scenario == 3) sensors = {nullptr};
    if (scenario == 6) sensors.clear();
    if (scenario == 7) sensors = {&invalid_sensor};
    Autopilot a(scenario == 2 ? nullptr : &f.vehicle, sensors,
                scenario == 4 ? nullptr : &f.navigation,
                scenario == 5 ? nullptr : &f.controller);
    QSignalSpy telemetry(&a, &Autopilot::telemetry_updated);
    QSignalSpy fault(&a, &Autopilot::fault_detected);
    a.run_cycle();
    QCOMPARE(telemetry.count(), 0);
    QCOMPARE(fault.count(), 1);
    QVERIFY2(fault[0][0].toString().contains(reason), qPrintable(fault[0][0].toString()));
    QCOMPARE(a.elapsed_seconds(), 0.0);
    QCOMPARE(f.navigation.get_position().altitude(), 150.0);
}
void StationTests::target_changes_without_restart() {
    Fixture f;
    QSignalSpy telemetry(&f.model, &Autopilot::telemetry_updated);
    f.model.run_cycle();
    f.model.set_target_altitude(300);
    f.model.run_cycle();
    QCOMPARE(telemetry.count(), 2);
    QVERIFY(std::abs(telemetry[1][1].toDouble() - 148.8) < 1e-9);
    QCOMPARE(f.model.elapsed_seconds(), 0.2);
    QVERIFY_THROWS_EXCEPTION(std::invalid_argument, f.model.set_target_altitude(501));
    QVERIFY_THROWS_EXCEPTION(std::invalid_argument, f.model.set_target_altitude(std::numeric_limits<double>::quiet_NaN()));
}
void StationTests::fleet_uses_polymorphism() {
    MainWindow w;
    auto* table = w.findChild<QTableWidget*>("tableFleet");
    QCOMPARE(table->rowCount(), 3);
    QCOMPARE(table->columnCount(), 5);
    QCOMPARE(table->item(0, 1)->text(), QString("Quadcopter"));
    QCOMPARE(table->item(1, 1)->text(), QString("FixedWingUAV"));
    QCOMPARE(table->item(2, 1)->text(), QString("Quadcopter"));
    QCOMPARE(table->item(0, 3)->text(), QString("4"));
    QCOMPARE(table->item(1, 3)->text(), QString("1"));
    QCOMPARE(table->item(2, 3)->text(), QString("4"));
    QVERIFY(label(w, "labelStatus")->text().startsWith("Stopped"));
}
void StationTests::timer_pause_and_resume() {
    MainWindow w;
    w.show();
    Autopilot* original = model(w);
    QSignalSpy telemetry(original, &Autopilot::telemetry_updated);
    QCOMPARE(timer(w)->interval(), 100);
    button(w, "btnStart")->click();
    QTRY_VERIFY_WITH_TIMEOUT(telemetry.count() >= 3, 1500);
    button(w, "btnPause")->click();
    const int count = telemetry.count();
    const QString altitude = label(w, "labelAltitude")->text();
    const QPointF position = marker(w)->pos();
    QVERIFY(label(w, "labelStatus")->text().startsWith("Paused"));
    QVERIFY(!timer(w)->isActive());
    QTest::qWait(250);
    QCOMPARE(telemetry.count(), count);
    QCOMPARE(series(w)->count(), count);
    QCOMPARE(label(w, "labelAltitude")->text(), altitude);
    QCOMPARE(marker(w)->pos(), position);
    button(w, "btnStart")->click();
    QTRY_VERIFY_WITH_TIMEOUT(telemetry.count() >= count + 3, 1500);
    button(w, "btnPause")->click();
    QCOMPARE(model(w), original);
    // Сравниваем всю последовательность с непрерывным эталонным запуском.
    Fixture reference;
    QSignalSpy expected(&reference.model, &Autopilot::telemetry_updated);
    for (int i = 0; i < telemetry.count(); ++i) reference.model.run_cycle();
    QCOMPARE(telemetry.count(), expected.count());
    for (int i = 0; i < telemetry.count(); ++i)
        for (int j = 0; j < 3; ++j)
            QCOMPARE(telemetry[i][j].toDouble(), expected[i][j].toDouble());
    QCOMPARE(w.findChild<QTableWidget*>("tableFleet")->item(0, 4)->text(), QString("Paused"));
}
void StationTests::ui_fault_three_levels_and_reset() {
    MainWindow w;
    w.show();
    QSignalSpy telemetry(model(w), &Autopilot::telemetry_updated);
    auto* events = w.findChild<QListWidget*>("listEvents");
    int dialogs = 0;
    QString dialog_text;
    QTimer closer;
    closer.setInterval(10);
    connect(&closer, &QTimer::timeout, &w, [&] {
        if (auto* box = qobject_cast<QMessageBox*>(QApplication::activeModalWidget())) {
            ++dialogs;
            dialog_text = box->text();
            box->accept();
        }
    });
    closer.start();
    button(w, "btnStart")->click();
    QTRY_VERIFY_WITH_TIMEOUT(telemetry.count() >= 2, 1500);
    button(w, "btnFaultSensor")->click();
    QTRY_VERIFY_WITH_TIMEOUT(label(w, "labelStatus")->text().startsWith("FAULT"), 1500);
    QVERIFY(!timer(w)->isActive());
    QCOMPARE(dialogs, 1);
    QVERIFY(dialog_text.contains("Gyroscope"));
    QVERIFY(label(w, "labelStatus")->text().contains("Gyroscope"));
    QCOMPARE(label(w, "labelStatus")->property("state").toString(), QString("fault"));
    QVERIFY(events->item(events->count() - 1)->text().contains("FAULT: Отказ сенсора: Gyroscope"));
    QVERIFY(events->item(events->count() - 1)->text().startsWith("[00:"));
    const int count = telemetry.count();
    const QString frozen = label(w, "labelAltitude")->text();
    QTest::qWait(200);
    QCOMPARE(telemetry.count(), count);
    QCOMPARE(label(w, "labelAltitude")->text(), frozen);
    const int events_before = events->count();
    button(w, "btnStart")->click(); // Повторная авария до сброса.
    QTRY_VERIFY_WITH_TIMEOUT(!timer(w)->isActive(), 1500);
    QCOMPARE(dialogs, 1);
    QVERIFY(events->count() > events_before);
    button(w, "btnReset")->click();
    QVERIFY(timer(w)->isActive());
    QCOMPARE(label(w, "labelStatus")->property("state").toString(), QString("running"));
    QTRY_VERIFY_WITH_TIMEOUT(telemetry.count() > count, 1500);
    button(w, "btnReset")->click(); // Повторный сброс безопасен.
    QVERIFY(timer(w)->isActive());
    button(w, "btnFaultNavigation")->click();
    QTRY_VERIFY_WITH_TIMEOUT(!timer(w)->isActive(), 1500);
    QCOMPARE(dialogs, 2); // Сброс разрешил новое первое предупреждение.
    QVERIFY(label(w, "labelStatus")->text().contains("GPS"));
    QVERIFY(dialog_text.contains("GPS"));
    button(w, "btnReset")->click();
    QTRY_VERIFY_WITH_TIMEOUT(telemetry.count() > count + 1, 1500);
}
void StationTests::long_run_bounds_and_marker_identity() {
    MainWindow w;
    QGraphicsItem* original_marker = marker(w);
    auto* scene = w.findChild<QGraphicsScene*>("flightScene");
    const int item_count = scene->items().size();
    for (int i = 0; i < 1000; ++i) model(w)->run_cycle();
    QCOMPARE(series(w)->count(), 600);
    QCOMPARE(marker(w), original_marker);
    QCOMPARE(scene->items().size(), item_count);
    QVERIFY(scene->sceneRect().contains(marker(w)->pos()));
    QVERIFY(std::abs(series(w)->points().last().x() - 100.0) < 1e-8);
}
void StationTests::screenshot_scenarios() {
    const QString directory = qEnvironmentVariable("STATION_CAPTURE_DIR");
    if (directory.isEmpty()) QSKIP("Set STATION_CAPTURE_DIR to render scenario screenshots");
    QVERIFY(QDir().mkpath(directory));
    MainWindow w;
    w.resize(1280, 900);
    w.show();
    auto capture = [&](const QString& name) {
        QApplication::processEvents();
        return w.grab().save(QDir(directory).filePath(name + ".png"));
    };
    QTest::qWait(100);
    QVERIFY(capture("01_stopped"));
    button(w, "btnStart")->click();
    // Ускоренный прогон той же модели для наглядной истории графика.
    for (int i = 0; i < 80; ++i) model(w)->run_cycle();
    QVERIFY(capture("02_running"));
    button(w, "btnPause")->click();
    QVERIFY(capture("03_paused"));
    button(w, "btnStart")->click();
    bool dialog_saved = false;
    bool dialog_save_ok = false;
    QTimer closer;
    closer.setInterval(30);
    connect(&closer, &QTimer::timeout, &w, [&] {
        if (auto* box = qobject_cast<QMessageBox*>(QApplication::activeModalWidget())) {
            if (!dialog_saved) {
                dialog_save_ok = box->grab().save(QDir(directory).filePath("04_first_warning.png"));
                dialog_saved = true;
            }
            box->accept();
        }
    });
    closer.start();
    button(w, "btnFaultSensor")->click();
    model(w)->run_cycle();
    QVERIFY(dialog_saved);
    QVERIFY(dialog_save_ok);
    QVERIFY(capture("05_sensor_fault"));
    button(w, "btnReset")->click();
    for (int i = 0; i < 20; ++i) model(w)->run_cycle();
    QVERIFY(capture("06_recovered"));
    w.findChild<QDoubleSpinBox*>("spinTarget")->setValue(300);
    for (int i = 0; i < 60; ++i) model(w)->run_cycle();
    QVERIFY(capture("07_target_300"));
    button(w, "btnFaultNavigation")->click();
    model(w)->run_cycle();
    QVERIFY(capture("08_gps_fault"));
    button(w, "btnReset")->click();
    button(w, "btnReset")->click();
    model(w)->run_cycle();
    QVERIFY(capture("09_repeated_reset"));
}

QTEST_MAIN(StationTests)
#include "tests.moc"
