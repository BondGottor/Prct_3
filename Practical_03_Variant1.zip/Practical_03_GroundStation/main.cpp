#include "mainwindow.h"
#include <QApplication>
#include <QFont>

int main(int argc, char* argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("Practical_03_GroundStation");
    QApplication::setApplicationVersion("1.0");
    QApplication::setOrganizationName("Practical03");
    QApplication::setFont(QFont("Segoe UI", 10));
    MainWindow window;
    window.show();
    return app.exec();
}
