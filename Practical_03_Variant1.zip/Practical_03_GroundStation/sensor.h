#pragma once
#include <QString>
class Sensor {
public:
    virtual ~Sensor() = default;
    virtual QString name() const = 0;
    virtual double read() const = 0;
    virtual bool is_ready() const = 0;
};
class ReadySensor : public Sensor {
public:
    explicit ReadySensor(double value);
    double read() const override;
    bool is_ready() const override;
    void set_ready(bool ready);
private:
    double value_;
    bool ready_ = true;
};
class Gyroscope final : public ReadySensor {
public:
    explicit Gyroscope(double value = 1.2);
    QString name() const override;
};
class Accelerometer final : public ReadySensor {
public:
    explicit Accelerometer(double value = 9.81);
    QString name() const override;
};
class Barometer final : public ReadySensor {
public:
    explicit Barometer(double value = 1012.5);
    QString name() const override;
};
