#pragma once
#include <QObject>
#include <QString>
#include <vector>
class UAV;
class Sensor;
class NavigationSystem;
class FlightController;

// Указатели не владеющие: зависимости должны жить дольше Autopilot.
class Autopilot final : public QObject {
    Q_OBJECT
public:
    Autopilot(UAV* vehicle, const std::vector<Sensor*>& sensors,
              NavigationSystem* navigation, FlightController* controller,
              QObject* parent = nullptr);
    static constexpr double cycle_dt() { return 0.1; }
    double elapsed_seconds() const;
    double target_altitude() const;
    void set_target_altitude(double altitude);
public slots:
    void run_cycle();
signals:
    void telemetry_updated(double altitude, double error, double control);
    void fault_detected(const QString& reason);
private:
    void fail(const QString& reason);
    UAV* vehicle_;
    std::vector<Sensor*> sensors_;
    NavigationSystem* navigation_;
    FlightController* controller_;
    double target_altitude_ = 200;
    quint64 cycles_ = 0;
};
